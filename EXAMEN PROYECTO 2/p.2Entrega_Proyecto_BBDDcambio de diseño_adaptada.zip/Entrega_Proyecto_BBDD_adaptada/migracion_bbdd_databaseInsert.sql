-- ============================================================
-- MIGRACIÓN BBDD - Adaptación para Arduino databaseInsert()
-- Proyecto Smart Residencial
-- ============================================================
-- Usar este archivo SOLO si ya tienes creada la base de datos.
-- Si vas a crear la base desde cero, usa smart_residencial.sql.
-- ============================================================

USE `smart_residencial`;

-- 1) Tabla Tipos: metadatos para interpretar cada sensor
ALTER TABLE `Tipos`
  ADD COLUMN `Unidad` VARCHAR(30) DEFAULT NULL AFTER `Nombre`,
  ADD COLUMN `Tipo_Dato` ENUM('NUMERICO','ALFANUMERICO','MIXTO') NOT NULL DEFAULT 'MIXTO' AFTER `Unidad`,
  ADD COLUMN `Descripcion` VARCHAR(255) DEFAULT NULL AFTER `Tipo_Dato`;

ALTER TABLE `Tipos`
  ADD UNIQUE KEY `uk_Tipos_Nombre` (`Nombre`);

UPDATE `Tipos` SET `Unidad` = 'ºC',     `Tipo_Dato` = 'MIXTO', `Descripcion` = 'Temperatura ambiental medida por DHT11' WHERE `Nombre` = 'Temperatura';
UPDATE `Tipos` SET `Unidad` = '%',      `Tipo_Dato` = 'MIXTO', `Descripcion` = 'Humedad relativa medida por DHT11' WHERE `Nombre` = 'Humedad';
UPDATE `Tipos` SET `Unidad` = '0-1000', `Tipo_Dato` = 'MIXTO', `Descripcion` = 'Nivel de luz calculado desde LDR' WHERE `Nombre` = 'Luminosidad';
UPDATE `Tipos` SET `Unidad` = 'ADC',    `Tipo_Dato` = 'MIXTO', `Descripcion` = 'Lectura analógica del sensor de gas' WHERE `Nombre` = 'Gas';
UPDATE `Tipos` SET `Unidad` = 'km/h',   `Tipo_Dato` = 'MIXTO', `Descripcion` = 'Velocidad estimada del viento' WHERE `Nombre` = 'Viento';

-- 2) Tabla Sensores: ahora acepta datos numéricos y alfanuméricos
ALTER TABLE `Sensores`
  MODIFY COLUMN `Valor` FLOAT DEFAULT NULL,
  ADD COLUMN `Valor_Alfanumerico` VARCHAR(100) DEFAULT NULL AFTER `Valor`,
  ADD COLUMN `Origen` VARCHAR(50) NOT NULL DEFAULT 'ESP32' AFTER `Id_Tipo`;

ALTER TABLE `Sensores`
  ADD KEY `idx_Sensores_Tipo_Fecha` (`Id_Tipo`, `Fecha`),
  ADD KEY `idx_Sensores_Fecha` (`Fecha`);

-- 3) Tabla Notificaciones: conserva también el estado textual asociado a la alerta
ALTER TABLE `Notificaciones`
  MODIFY COLUMN `Dato` FLOAT DEFAULT NULL,
  ADD COLUMN `Dato_Alfanumerico` VARCHAR(100) DEFAULT NULL AFTER `Dato`;

ALTER TABLE `Notificaciones`
  ADD KEY `idx_Notificaciones_Fecha` (`Fecha`),
  ADD KEY `idx_Notificaciones_Sensor` (`Id_Sensor`);

-- 4) Vista de consulta unificada para mostrar lecturas con unidad y texto
DROP VIEW IF EXISTS `Vista_Lecturas_Sensores`;
CREATE VIEW `Vista_Lecturas_Sensores` AS
SELECT
  s.`Id_Sensor`,
  t.`Nombre` AS `Tipo`,
  t.`Unidad`,
  s.`Valor`,
  s.`Valor_Alfanumerico`,
  s.`Fecha`,
  s.`Origen`,
  s.`Activo`
FROM `Sensores` s
JOIN `Tipos` t ON s.`Id_Tipo` = t.`Id_Tipos`;

-- 5) Ejemplo compatible con el método Arduino:
-- databaseInsert(4, 2300.0, "GAS_ALTO")
INSERT INTO `Sensores` (`Valor`, `Valor_Alfanumerico`, `Fecha`, `Id_Tipo`, `Activo`)
VALUES (2300.0, 'GAS_ALTO', NOW(), 4, 1);

-- 6) Umbral de viento usado por el firmware ESP32 actualizado
INSERT INTO `Conf_Alertas` (`Valor`, `Id_Tipo`, `Activo`)
SELECT 50.0, 5, 1
WHERE NOT EXISTS (
  SELECT 1 FROM `Conf_Alertas` WHERE `Id_Tipo` = 5 AND `Activo` = 1
);
