-- ============================================================
-- MIGRACION SOLO SENSOR ORDINARIO
-- Usar si la BBDD ya esta adaptada a databaseInsert()
-- y solo falta registrar el nuevo tipo de sensor.
-- ============================================================

USE `smart_residencial`;

INSERT INTO `Tipos` (`Id_Tipos`, `Nombre`, `Unidad`, `Tipo_Dato`, `Descripcion`, `Activo`)
VALUES (8, 'Sensor Ordinario', '%', 'MIXTO', 'Sensor analogico ordinario leido por el ESP32', 1)
ON DUPLICATE KEY UPDATE
  `Nombre` = VALUES(`Nombre`),
  `Unidad` = VALUES(`Unidad`),
  `Tipo_Dato` = VALUES(`Tipo_Dato`),
  `Descripcion` = VALUES(`Descripcion`),
  `Activo` = VALUES(`Activo`);
